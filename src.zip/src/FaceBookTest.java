import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class FaceBookTest {
	WebDriver driver = new FirefoxDriver();
	@Before
	public void initfaceBook(){
		
		driver.get("https://www.facebook.com");
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
	}
	@Test
	public void addComment(){
		
		FacebookLogIn fbLogin = new FacebookLogIn(driver);
		HomePage usersPage =  fbLogin.login("panchenko_victoria@ukr.net", "XXX");
		usersPage.postComment("Teeest comment 1");
		usersPage.removeLastComment();
		usersPage.logOut();
	}
	
	
	@After	
	public void closeTest(){	
		driver.close();
		
	}
	
}
