
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

// Class for user's Home page

public class HomePage {
	final WebDriver driver;
	private WebElement commentsArea;
	private WebElement posCommentButton;
	//private WebElement streamArea;
	private WebElement userNavigationLabel;
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
		setCommentArea();
		setPostCommentButton();
		setNavigationLable();
		}
	private void setCommentArea(){
		commentsArea = driver.findElement(By.id("u_0_14"));	
	}
	
	private void setPostCommentButton(){
		posCommentButton = driver.findElement(By.id("u_0_y")).findElement(By.className("clearfix")).findElement(By.className("selected"));
	}
	public void postComment(String comment){
		commentsArea.sendKeys(comment);
		posCommentButton.click();
		(new WebDriverWait(driver, 100))
        .until(ExpectedConditions.textToBePresentInElement(By.className("userContent"),comment));
	}
	private void setNavigationLable(){
		userNavigationLabel = driver.findElement(By.id("userNavigationLabel"));
	}
	private void clickOnNavigationLable(){
		userNavigationLabel.click();
	}
	private void clickOnLogOut(){
		WebElement logoutLink = driver.findElement(By.className("uiLinkButton"));
		logoutLink.click();
	}
	
	public FacebookLogIn logOut(){
		clickOnNavigationLable();
		clickOnLogOut();
		return new FacebookLogIn(driver);
	}
	
	public void removeLastComment(){
		List<WebElement> allElements = driver.findElements(By.xpath("//ul[@id='home_stream']/li")); 
		WebElement commentsMenu = allElements.get(0).findElement(By.className("highlightEditSelectorButton"));
			commentsMenu.click();
			(new WebDriverWait(driver, 100))
            .until(ExpectedConditions.visibilityOfElementLocated(By.className("__MenuItem")));

			List<WebElement> amendOptions = driver.findElements(By.className("__MenuItem"));
			
			for (WebElement itemMenu: amendOptions) {
				if (itemMenu.getText().equals("�������")){
					System.out.println("it is found");
					if (itemMenu.findElements(By.tagName("a")).size()!=0){
						itemMenu.findElement(By.tagName("a")).click();
						
						if (driver.findElements(By.className("uiButtonConfirm")).size()!=0){
							WebElement confirmButton = driver.findElement(By.className("uiButtonConfirm"));
							confirmButton.click();
							
							if (driver.findElements(By.className("uiButtonConfirm")).size()!=0){
								WebElement finalconfirmation = driver.findElement(By.className("uiButtonConfirm"));
								finalconfirmation.click();
						}
							
					}			
					
				}
				
			}
		
		}
		

		
	}
	
	private void setA(){
		// all comments are located in UL:
		//home_stream 
		// first il in that list is last one posted.
		// there is <a>== button classname = highlightEditSelectorButton uiStreamContextButton alwaysShowHideButton _p
		// click on it appears new options . we need to click on element with classname = _54nh
		// but we need to check that it has REmove text inside! or just take seccond element
		
		//
		
	}
}

