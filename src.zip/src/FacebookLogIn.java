import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

// Class for face book login page.

public class FacebookLogIn {
	final  WebDriver driver;
	private WebElement userEmail;
	private WebElement userPassword;
	private WebElement loginButton;
	
	public FacebookLogIn(WebDriver driver) {
		this.driver = driver;
		setEmail();
		setPassword();
		setLoginButton();
		}
	
	private void setEmail(){
		userEmail = driver.findElement(By.id("email"));
	}
	private void setPassword(){
		userPassword = driver.findElement(By.id("pass"));
	}
	private void setLoginButton(){
		loginButton = driver.findElement(By.id("loginbutton"));
	}
	
	public void enterLogin(String email){
		userEmail.clear();
		userEmail.sendKeys(email);
	}
	public void enterPass(String pass){
		userPassword.clear();
		userPassword.sendKeys(pass);
	}
	public void clickLogInButton(){
		loginButton.click();
	}
	
	public HomePage login(String email,String pass){
		enterLogin(email);
		enterPass(pass);
		clickLogInButton();
		
		return new HomePage(driver);
	}
	
}
