Write a shell command to count the number of times the word 'Integer' occurs as the first word in a sentence.
