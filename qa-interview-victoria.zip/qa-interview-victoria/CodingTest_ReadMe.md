## QA Interview Coding Exercise

## Description
This exercise is mainly for us to understand your coding and analytical skills. We are looking for working code that satisfies the following requirements but if you would like to add more things to the scope of this exercise, that would be considered for bonus points!

## Requirements
* In this repository, you will find a file with a list of words. Write a program to arrange them in ascending order of their length. 
  For example, if the file contains Java, C, Perl, Python, C#, the output would be C, C#, Perl, Java, Python.
* Include documentation with instructions on how to execute your program, required libraries etc.

## What to use
* You can use any programming or scripting language you like.  
* Create a feature branch in this repo and commit your code in the branch. Then create a Pull Request when you are ready to submit your task. You can refer https://help.github.com/categories/54/articles for more help on using gitub.
